import React from 'react'
import Layout from './Layout'
export default function App(){
  return (<Layout>
    <div style={{padding:20}}>
      <h3>Welcome to dashboard</h3>
      <p>Use the menu to navigate.</p>
    </div>
  </Layout>)
}
