const jwt = require('jsonwebtoken');
const cfg = require('../config/jwt');
module.exports = (req,res,next)=>{
  const h=req.headers.authorization||''; const t=h.startsWith('Bearer ')?h.slice(7):null;
  if(!t) return res.status(401).json({ error:{message:'Missing token'} });
  try{ req.user = jwt.verify(t, cfg.accessSecret); next(); }catch(e){ console.error(e); res.status(401).json({
error:{message:'Invalid token'} }) }
};
