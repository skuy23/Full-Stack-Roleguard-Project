const r = require('express').Router();
const auth = require('../middleware/auth');
const c = require('../controllers/authController');
r.post('/register', c.register);
r.post('/login', c.login);
r.post('/refresh', c.refresh);
r.post('/logout-all', auth, async (req,res)=>{
  const User = require('../models/User');
  await User.findByIdAndUpdate(req.user.sub, { $inc: { tokenVersion: 1 } });
  res.json({ data:{ ok:true } });
});
module.exports = r;
