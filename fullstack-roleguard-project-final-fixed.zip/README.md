Fullstack RoleGuard sample - rebuilt minimal

Run backend and frontend (both require Node.js + MongoDB):

1) Backend
cd apps/api
npm install
copy .env.example to .env if needed
npm run seed-users
npm run dev

2) Frontend
cd apps/web
npm install
npm run dev

Open http://localhost:5173/login
Default accounts:
- admin@example.com / Admin123!
- manager@example.com / Manager123!
- user@example.com / User123!
